import Form from "../components/commons/Form";

const Bags = () => {
  return (
    <div>
        <Form />
    </div>
  )
}

export default Bags