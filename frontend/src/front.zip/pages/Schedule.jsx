// import Form from "../components/commons/Form"

// const Schedule = () => {
//   return (
//     <div>
//         <Form></Form>
//     </div>
//   )
// }

// export default Schedule